
def welcome(name):
    output = "Hello {} and welcome to the World of Games (WoG).\nHere you can find many cool games to play".format(name)
    return output


def load_game():
    game_to_play = input("\nPlease Choose a game to play:\n1. Memory Game - a sequence of numbers will appear for 1 second and you have to guess it back\n2. Guess Game - guess a number and see if you chose like the computer\n3. Currency Roulette - try and guess the value of a random amount of USD in ILS\n")
    difficulty = input("\nPlease choose game difficulty from 1 to 5: ")


def main():
    welcome_message = welcome(input("Enter your name:\n"))
    print(welcome_message)
    load_game()


if __name__ == "__main__":
    main()

